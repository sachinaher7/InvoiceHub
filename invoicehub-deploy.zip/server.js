/**
 * InvoiceHub Backend Server
 * Single-user SaaS-style backend with auth, TOTP, file uploads, and JSON state storage.
 *
 * Data layout (under DATA_DIR):
 *   state.json         -> the user's app state (full JSON blob)
 *   auth.json          -> { username, passwordHash, totpSecret, totpEnabled, createdAt }
 *   uploads/<fileId>   -> raw bytes for invoice PDFs / company logos
 *   uploads-meta.json  -> { fileId: { name, mime, size, createdAt } }
 *
 * All writes are atomic (write-to-tmp + rename).
 */

const express = require('express');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const bcrypt = require('bcryptjs');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ===== Configuration =====
const PORT = parseInt(process.env.PORT || '3000', 10);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const NODE_ENV = process.env.NODE_ENV || 'development';

const STATE_FILE = path.join(DATA_DIR, 'state.json');
const AUTH_FILE = path.join(DATA_DIR, 'auth.json');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const UPLOADS_META = path.join(DATA_DIR, 'uploads-meta.json');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const SESSION_SECRET_FILE = path.join(DATA_DIR, '.session-secret');

// Ensure directories exist
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });
fs.mkdirSync(SESSIONS_DIR, { recursive: true });

// Persist session secret so sessions survive server restarts
let SESSION_SECRET;
if (fs.existsSync(SESSION_SECRET_FILE)) {
    SESSION_SECRET = fs.readFileSync(SESSION_SECRET_FILE, 'utf8').trim();
} else {
    SESSION_SECRET = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(SESSION_SECRET_FILE, SESSION_SECRET, { mode: 0o600 });
}

// ===== Atomic file helpers =====
function readJson(filepath, defaultVal = null) {
    try {
        return JSON.parse(fs.readFileSync(filepath, 'utf8'));
    } catch (e) {
        return defaultVal;
    }
}
function writeJsonAtomic(filepath, data) {
    const tmp = `${filepath}.tmp.${process.pid}.${Date.now()}`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, filepath);
}

function loadAuth() { return readJson(AUTH_FILE, null); }
function saveAuth(auth) { writeJsonAtomic(AUTH_FILE, auth); }

// ===== Bootstrap auth.json on first run =====
async function bootstrapAuth() {
    if (loadAuth()) return;
    const username = process.env.INITIAL_USERNAME || 'admin';
    const password = process.env.INITIAL_PASSWORD || 'changeme';
    const passwordHash = await bcrypt.hash(password, 12);
    saveAuth({
        username,
        passwordHash,
        totpSecret: null,
        totpEnabled: false,
        createdAt: new Date().toISOString()
    });
    console.log(`[bootstrap] Initialized auth for username: ${username}`);
    console.log(`[bootstrap] Change password from the app's Security settings after first login.`);
}

// ===== Rate limiting (simple in-memory) =====
const loginAttempts = new Map(); // ip -> { count, firstAt }
function rateLimitLogin(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    const window = 60 * 1000; // 1 minute
    const max = 5;

    const entry = loginAttempts.get(ip);
    if (entry && now - entry.firstAt < window) {
        if (entry.count >= max) {
            return res.status(429).json({ error: 'Too many login attempts. Try again in a minute.' });
        }
        entry.count++;
    } else {
        loginAttempts.set(ip, { count: 1, firstAt: now });
    }
    // Cleanup occasionally
    if (loginAttempts.size > 1000) {
        for (const [k, v] of loginAttempts) {
            if (now - v.firstAt > window) loginAttempts.delete(k);
        }
    }
    next();
}

// ===== Express setup =====
const app = express();
app.set('trust proxy', 1); // trust nginx in front

app.use(express.json({ limit: '5mb' })); // state.json blob
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

app.use(session({
    name: 'ihub.sid',
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: new FileStore({
        path: SESSIONS_DIR,
        ttl: 60 * 60 * 24 * 30, // 30 days
        retries: 1,
        logFn: () => {} // suppress noisy logs
    }),
    cookie: {
        httpOnly: true,
        secure: NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 24 * 30
    }
}));

function requireAuth(req, res, next) {
    if (!req.session || !req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }
    next();
}

// =====================================================================
// AUTH ROUTES
// =====================================================================

app.get('/api/auth/me', (req, res) => {
    const auth = loadAuth();
    res.json({
        authenticated: !!(req.session && req.session.userId),
        username: req.session?.userId ? auth.username : null,
        totpEnabled: auth ? !!auth.totpEnabled : false
    });
});

app.post('/api/auth/login', rateLimitLogin, async (req, res) => {
    const { username, password, totp } = req.body || {};
    const auth = loadAuth();
    if (!auth) return res.status(500).json({ error: 'Server not initialized' });

    if (!username || !password || username !== auth.username) {
        return res.status(401).json({ error: 'Invalid username or password' });
    }
    const valid = await bcrypt.compare(password, auth.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid username or password' });

    if (auth.totpEnabled) {
        if (!totp) return res.status(401).json({ error: 'TOTP code required', requireTOTP: true });
        const verified = speakeasy.totp.verify({
            secret: auth.totpSecret, encoding: 'base32', token: String(totp), window: 1
        });
        if (!verified) return res.status(401).json({ error: 'Invalid TOTP code' });
    }

    req.session.userId = auth.username;
    req.session.loginAt = new Date().toISOString();
    res.json({ ok: true, totpEnabled: !!auth.totpEnabled, username: auth.username });
});

app.post('/api/auth/logout', (req, res) => {
    if (req.session) req.session.destroy(() => res.json({ ok: true }));
    else res.json({ ok: true });
});

// Begin TOTP setup — returns QR code. Requires current password.
app.post('/api/auth/setup-totp', requireAuth, async (req, res) => {
    const { password } = req.body || {};
    const auth = loadAuth();
    const valid = await bcrypt.compare(password || '', auth.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Password incorrect' });

    const secret = speakeasy.generateSecret({
        name: `InvoiceHub (${auth.username})`,
        issuer: 'InvoiceHub',
        length: 20
    });
    req.session.pendingTotpSecret = secret.base32;
    const qr = await QRCode.toDataURL(secret.otpauth_url);
    res.json({ qr, secret: secret.base32 });
});

// Verify the TOTP code and enable 2FA
app.post('/api/auth/verify-totp', requireAuth, (req, res) => {
    const { token } = req.body || {};
    const secret = req.session.pendingTotpSecret;
    if (!secret) return res.status(400).json({ error: 'No pending TOTP setup' });
    const verified = speakeasy.totp.verify({
        secret, encoding: 'base32', token: String(token || ''), window: 1
    });
    if (!verified) return res.status(401).json({ error: 'Invalid code' });
    const auth = loadAuth();
    auth.totpSecret = secret;
    auth.totpEnabled = true;
    saveAuth(auth);
    delete req.session.pendingTotpSecret;
    res.json({ ok: true });
});

// Disable TOTP — requires password and current TOTP
app.post('/api/auth/disable-totp', requireAuth, async (req, res) => {
    const { password, totp } = req.body || {};
    const auth = loadAuth();
    const valid = await bcrypt.compare(password || '', auth.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Password incorrect' });
    if (auth.totpEnabled) {
        const verified = speakeasy.totp.verify({
            secret: auth.totpSecret, encoding: 'base32', token: String(totp || ''), window: 1
        });
        if (!verified) return res.status(401).json({ error: 'Invalid TOTP' });
    }
    auth.totpEnabled = false;
    auth.totpSecret = null;
    saveAuth(auth);
    res.json({ ok: true });
});

app.post('/api/auth/change-password', requireAuth, async (req, res) => {
    const { oldPassword, newPassword, totp } = req.body || {};
    const auth = loadAuth();
    const valid = await bcrypt.compare(oldPassword || '', auth.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Current password incorrect' });
    if (auth.totpEnabled) {
        const verified = speakeasy.totp.verify({
            secret: auth.totpSecret, encoding: 'base32', token: String(totp || ''), window: 1
        });
        if (!verified) return res.status(401).json({ error: 'Invalid TOTP' });
    }
    if (!newPassword || newPassword.length < 8) {
        return res.status(400).json({ error: 'New password must be at least 8 characters' });
    }
    auth.passwordHash = await bcrypt.hash(newPassword, 12);
    saveAuth(auth);
    res.json({ ok: true });
});

// =====================================================================
// DATA ROUTES
// =====================================================================

const DEFAULT_STATE = {
    companies: [],
    currentCompanyId: null,
    customers: [],
    vendors: [],
    quotations: [],
    proformas: [],
    taxInvoices: [],
    purchaseOrders: [],
    bankBook: [],
    openingBalances: {},
    bbCounters: {},
    documentCounters: {}
};

app.get('/api/data', requireAuth, (req, res) => {
    const state = readJson(STATE_FILE, DEFAULT_STATE);
    res.json(state);
});

app.post('/api/data', requireAuth, (req, res) => {
    if (!req.body || typeof req.body !== 'object') {
        return res.status(400).json({ error: 'Invalid data' });
    }
    writeJsonAtomic(STATE_FILE, req.body);
    res.json({ ok: true, savedAt: new Date().toISOString() });
});

// =====================================================================
// FILE UPLOAD ROUTES (PDFs / images for invoices and logos)
// =====================================================================

const upload = multer({
    storage: multer.diskStorage({
        destination: UPLOADS_DIR,
        filename: (req, file, cb) => cb(null, crypto.randomUUID())
    }),
    limits: { fileSize: 20 * 1024 * 1024 } // 20MB per file
});

app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const meta = readJson(UPLOADS_META, {});
    meta[req.file.filename] = {
        name: req.file.originalname,
        mime: req.file.mimetype,
        size: req.file.size,
        createdAt: new Date().toISOString()
    };
    writeJsonAtomic(UPLOADS_META, meta);
    res.json({
        fileId: req.file.filename,
        fileName: req.file.originalname,
        mime: req.file.mimetype,
        size: req.file.size
    });
});

const FILE_ID_RE = /^[a-f0-9-]+$/i;

app.get('/api/file/:fileId', requireAuth, (req, res) => {
    const fileId = req.params.fileId;
    if (!FILE_ID_RE.test(fileId)) return res.status(400).end();
    const filePath = path.join(UPLOADS_DIR, fileId);
    if (!fs.existsSync(filePath)) return res.status(404).end();
    const meta = readJson(UPLOADS_META, {});
    const m = meta[fileId];
    if (m) {
        res.setHeader('Content-Type', m.mime);
        res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(m.name)}"`);
        res.setHeader('Cache-Control', 'private, max-age=3600');
    }
    fs.createReadStream(filePath).pipe(res);
});

app.delete('/api/file/:fileId', requireAuth, (req, res) => {
    const fileId = req.params.fileId;
    if (!FILE_ID_RE.test(fileId)) return res.status(400).end();
    const filePath = path.join(UPLOADS_DIR, fileId);
    try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        const meta = readJson(UPLOADS_META, {});
        delete meta[fileId];
        writeJsonAtomic(UPLOADS_META, meta);
        res.json({ ok: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// =====================================================================
// HEALTH + STATIC
// =====================================================================

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use(express.static(PUBLIC_DIR));

// SPA fallback - any unknown non-API route serves index.html
app.get(/^\/(?!api).*/, (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// =====================================================================
// START
// =====================================================================

bootstrapAuth().then(() => {
    app.listen(PORT, '127.0.0.1', () => {
        console.log(`[invoicehub] listening on 127.0.0.1:${PORT}  (env=${NODE_ENV})`);
        console.log(`[invoicehub] data dir: ${DATA_DIR}`);
    });
}).catch(err => {
    console.error('[fatal]', err);
    process.exit(1);
});
