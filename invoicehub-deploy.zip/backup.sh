#!/bin/bash
# ============================================================
#  InvoiceHub daily backup -> Google Drive (via rclone)
#  Runs from cron (see install steps).
# ============================================================
set -e

DATA_DIR="/home/ubuntu/invoicehub/data"
BACKUP_TMP="/tmp/invoicehub-backup"
RCLONE_REMOTE="gdrive:InvoiceHub-Backups"   # rclone remote name "gdrive" + folder
KEEP_DAYS=30

DATE=$(date +%Y-%m-%d_%H%M)
ARCHIVE="invoicehub_$DATE.tar.gz"

mkdir -p "$BACKUP_TMP"
cd "$DATA_DIR"

# Create compressed archive of state.json + auth.json + uploads/ + uploads-meta.json
tar -czf "$BACKUP_TMP/$ARCHIVE" \
    --exclude="sessions" \
    --exclude=".session-secret" \
    --exclude="*.tmp.*" \
    state.json auth.json uploads/ uploads-meta.json 2>/dev/null || true

# Upload to Google Drive
rclone copy "$BACKUP_TMP/$ARCHIVE" "$RCLONE_REMOTE/" --quiet

# Remove local temp archive
rm -f "$BACKUP_TMP/$ARCHIVE"

# Prune old remote backups (older than KEEP_DAYS days)
rclone delete "$RCLONE_REMOTE/" --min-age "${KEEP_DAYS}d" --quiet 2>/dev/null || true

echo "[backup] $DATE OK -> $RCLONE_REMOTE/$ARCHIVE"
