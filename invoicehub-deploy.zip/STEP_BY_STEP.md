# InvoiceHub — Lightsail Deployment Guide

Complete setup from zero to a live, secure, auto-backed-up app at **https://accounts.indilok.in**.

**Estimated time:** 45 minutes total. Everything below assumes you do it once and forget about it.

---

## What you'll have at the end

- ✅ App live at `https://accounts.indilok.in`
- ✅ Username `GTAC-KRUNAL` + password `GTAC2026` (changeable from the app)
- ✅ Two-factor authentication via Google Authenticator
- ✅ All data on the server (not browser localStorage)
- ✅ Daily 2 AM automatic backup to Google Drive (kept for 30 days)
- ✅ Weekly Lightsail snapshot (full disaster recovery)
- ✅ Auto-restart if server crashes
- ✅ HTTPS with auto-renewing certificate

---

## Step 1 — Create the Lightsail instance (5 min)

1. Sign in to **https://lightsail.aws.amazon.com**
2. Click **"Create instance"**
3. Configure:
   - **Region:** Mumbai, Zone A (`ap-south-1a`)
   - **Platform:** Linux/Unix
   - **Blueprint:** OS Only → **Ubuntu 22.04 LTS**
   - **Plan:** $3.50/month (512 MB / 2 vCPU / 20 GB SSD / 1 TB transfer)
   - **Instance name:** `invoicehub`
4. Click **Create instance**. Wait ~60 seconds for it to start.

## Step 2 — Static IP (2 min)

1. Lightsail → **Networking** tab → **Create static IP**
2. Region: Mumbai
3. Attach to: `invoicehub`
4. Name: `invoicehub-ip`
5. Click Create. **Copy the IP address** — you'll need it next. (Looks like `13.234.x.x`)

## Step 3 — DNS A record at indilok.in (5 min + DNS wait)

Go to wherever you manage `indilok.in` DNS (GoDaddy / Cloudflare / wherever):

1. Add an **A record**:
   - **Name/Host:** `accounts`
   - **Value/Points to:** your static IP (e.g. `13.234.x.x`)
   - **TTL:** 600 (or whatever default)
2. Save.

Wait 5–15 minutes for DNS to propagate. Verify with:

```bash
# From your local machine
nslookup accounts.indilok.in
# Should return your static IP
```

If it still shows the old/no value, wait longer before doing Step 7.

## Step 4 — Open ports in Lightsail firewall (1 min)

1. Lightsail → click your `invoicehub` instance → **Networking** tab
2. Under **IPv4 Firewall**, ensure these are present (add if missing):
   - SSH — TCP — 22 (already there)
   - HTTP — TCP — 80
   - HTTPS — TCP — 443

## Step 5 — Upload the app files (5 min)

You have **two options** — pick whichever feels easier.

### Option A — Browser-based SSH (no setup, fully in browser)

1. From the Lightsail instance page, click **"Connect using SSH"** (orange button). A terminal opens in your browser.
2. In that terminal, paste this to set up the directory:
   ```bash
   mkdir -p ~/invoicehub/public
   cd ~/invoicehub
   ```
3. Now you need to upload 7 files. Easiest way in the browser SSH: open each file in nano and paste its content.

   For each file below, run `nano <path>`, paste the content, then `Ctrl+O`, `Enter`, `Ctrl+X`:
   - `nano ~/invoicehub/server.js` → paste contents of **server.js**
   - `nano ~/invoicehub/package.json` → paste contents of **package.json**
   - `nano ~/invoicehub/public/index.html` → paste contents of **public/index.html** (the big one, ~300KB)
   - `nano ~/invoicehub/install.sh` → paste contents of **install.sh**
   - `nano ~/invoicehub/backup.sh` → paste contents of **backup.sh**
   - `nano ~/invoicehub/restore.sh` → paste contents of **restore.sh**

   *(Pasting works with `Ctrl+Shift+V` or right-click → Paste in most browsers.)*

### Option B — SCP from your laptop (faster for big files, especially index.html)

1. Lightsail → **Account** (top right) → **SSH keys** tab → download "Default key for ap-south-1" (a `.pem` file).
2. From your laptop terminal, in the folder containing all the deploy files:
   ```bash
   chmod 400 ~/Downloads/LightsailDefaultKey-ap-south-1.pem
   
   scp -i ~/Downloads/LightsailDefaultKey-ap-south-1.pem \
     server.js package.json install.sh backup.sh restore.sh \
     ubuntu@<YOUR-STATIC-IP>:/home/ubuntu/invoicehub/
   
   scp -i ~/Downloads/LightsailDefaultKey-ap-south-1.pem \
     public/index.html \
     ubuntu@<YOUR-STATIC-IP>:/home/ubuntu/invoicehub/public/
   ```
3. SSH in:
   ```bash
   ssh -i ~/Downloads/LightsailDefaultKey-ap-south-1.pem ubuntu@<YOUR-STATIC-IP>
   ```
   (You'll need to first `mkdir -p /home/ubuntu/invoicehub/public` over the browser SSH, OR run the scp in two stages — upload to /home/ubuntu first, then move.)

   Easier: First connect via browser SSH and run:
   ```bash
   mkdir -p ~/invoicehub/public
   ```
   Then run the scp commands from your laptop.

## Step 6 — Run the installer (10 min)

In the SSH session on your Lightsail server:

```bash
cd ~/invoicehub
chmod +x install.sh backup.sh restore.sh
bash install.sh
```

The script will:
1. Update Ubuntu packages
2. Install Node.js 20, nginx, certbot, rclone, ufw
3. Install npm dependencies for the app
4. Bootstrap your auth (`GTAC-KRUNAL` / `GTAC2026`)
5. Create a systemd service so it auto-restarts on crash/reboot
6. Configure nginx to proxy from `accounts.indilok.in` → port 3000
7. Open the firewall (HTTP, HTTPS, SSH)
8. **Pause and ask you to confirm DNS is set** before requesting an SSL cert

When it pauses asking about Let's Encrypt, **only continue if `nslookup accounts.indilok.in` returns your IP.** Otherwise wait a few more minutes for DNS, then re-run `bash install.sh` (it's idempotent).

If everything succeeds, you'll see:
```
✓ Installation complete!
Visit: https://accounts.indilok.in
```

## Step 7 — First login + enable 2FA (5 min)

1. Open **https://accounts.indilok.in** in your browser.
2. Log in with `GTAC-KRUNAL` / `GTAC2026`.
3. Click your username (top right) → **🔐 Security & Password**
4. Click **🔐 Enable 2FA**
5. Enter your password (`GTAC2026`)
6. Open **Google Authenticator** on your phone → tap **+** → **Scan a QR code**
7. Scan the QR shown on screen
8. Type the 6-digit code from the app → click **Enable 2FA**

**Important — save your TOTP secret somewhere safe** (the long base32 string shown below the QR). If you ever lose your phone, this lets you re-add the account in a new authenticator app. Save it in a password manager (1Password, Bitwarden) or print and lock it away.

9. While you're here, also click **Change Password** and set a stronger one. The `GTAC2026` password is the bootstrap; you should change it now. Min 8 chars.

## Step 8 — Set up Google Drive backup (10 min)

In your SSH session:

```bash
rclone config
```

Answer the prompts:
- `n` (new remote)
- name: `gdrive`
- Storage type: scroll until you see Google Drive → enter its number (typically around 18, but check the menu)
- `client_id`: leave blank, press Enter
- `client_secret`: leave blank, press Enter
- `scope`: choose `1` (Full access)
- `service_account_file`: leave blank, Enter
- Edit advanced config: `n`
- Use auto config: `n` (since this is a server with no browser)
- It will give you a long URL. **Copy it** and paste in your laptop's browser.
- Sign in to your Google account, allow access. You'll get a token like `{"access_token": "..."}`.
- Paste that whole JSON back into the SSH terminal.
- Configure as Shared Drive: `n`
- Yes this is OK: `y`
- Quit config: `q`

Test it:
```bash
rclone mkdir gdrive:InvoiceHub-Backups
rclone lsf gdrive:
# Should list the InvoiceHub-Backups folder
```

Run a backup manually to confirm:
```bash
bash ~/invoicehub/backup.sh
# You should see: [backup] 2026-04-30_xxxx OK -> gdrive:InvoiceHub-Backups/...
```

Verify on your Drive — go to drive.google.com, you'll see `InvoiceHub-Backups/invoicehub_2026-04-30_xxxx.tar.gz`.

## Step 9 — Schedule daily backups (1 min)

Add a cron job:
```bash
crontab -e
```
Choose nano if asked. Add this line at the bottom:
```
0 2 * * * /bin/bash /home/ubuntu/invoicehub/backup.sh >> /var/log/invoicehub-backup.log 2>&1
```
Save (`Ctrl+O`, Enter, `Ctrl+X`).

This runs every day at 2:00 AM IST. Check it's scheduled:
```bash
crontab -l
```

## Step 10 — Weekly Lightsail snapshots (1 min)

This is your full disaster recovery — if the entire instance dies, you can restore from a snapshot.

1. Lightsail → click `invoicehub` instance → **Snapshots** tab
2. Toggle **"Enable automatic snapshots"** ON
3. Choose a time (e.g. 3:00 AM, after the backup runs)
4. Click Save

Cost: ~₹15/month for snapshots of a 20GB disk. Keeps 7 most recent automatically.

---

## You're done! 🎉

Your stack now:

| Layer | Purpose |
|---|---|
| **Lightsail instance** | Runs the app 24/7, auto-restarts on crashes |
| **systemd service** | Process manager — `sudo systemctl status invoicehub` |
| **nginx** | HTTPS termination, reverse proxy to Node |
| **Let's Encrypt** | SSL cert, auto-renews every 90 days |
| **Local data** | `/home/ubuntu/invoicehub/data/` — your real data |
| **Daily Drive backup** | 2 AM nightly, last 30 days kept |
| **Weekly snapshot** | Full instance image, 7 most recent kept |

Three independent layers of data protection. You'd have to lose your laptop, Lightsail, AND Google Drive simultaneously to lose data.

---

## Common operations

### Check if the app is running
```bash
sudo systemctl status invoicehub
```

### See logs
```bash
tail -f /var/log/invoicehub.log
tail -f /var/log/invoicehub-backup.log
```

### Restart the app (e.g., after editing files)
```bash
sudo systemctl restart invoicehub
```

### Update the app code (when I send you a new HTML)
```bash
# From your laptop:
scp -i key.pem public/index.html ubuntu@<IP>:/home/ubuntu/invoicehub/public/

# OR via browser SSH:
nano ~/invoicehub/public/index.html
# (paste new content)

# No need to restart — index.html is served as a static file.
```

To update server.js (if I send a backend update):
```bash
scp -i key.pem server.js ubuntu@<IP>:/home/ubuntu/invoicehub/
ssh -i key.pem ubuntu@<IP> 'cd /home/ubuntu/invoicehub && npm install --omit=dev --silent && sudo systemctl restart invoicehub'
```

### Restore from a backup
```bash
# List available backups
ls -lh /tmp # for local
rclone lsf gdrive:InvoiceHub-Backups/

# Restore latest from Drive
bash ~/invoicehub/restore.sh latest

# Or restore a specific file
rclone copy gdrive:InvoiceHub-Backups/invoicehub_2026-04-15_0200.tar.gz /tmp/
bash ~/invoicehub/restore.sh /tmp/invoicehub_2026-04-15_0200.tar.gz
```

### Forgot password (lockout recovery)
SSH in and run:
```bash
cd ~/invoicehub
node -e "
const bcrypt=require('bcryptjs');
const fs=require('fs');
const auth=JSON.parse(fs.readFileSync('data/auth.json'));
auth.passwordHash=bcrypt.hashSync('NEW_PASSWORD_HERE',12);
fs.writeFileSync('data/auth.json',JSON.stringify(auth,null,2));
console.log('Password reset.');
"
sudo systemctl restart invoicehub
```

### Lost authenticator (need to reset 2FA)
SSH in and run:
```bash
cd ~/invoicehub
node -e "
const fs=require('fs');
const auth=JSON.parse(fs.readFileSync('data/auth.json'));
auth.totpEnabled=false;
auth.totpSecret=null;
fs.writeFileSync('data/auth.json',JSON.stringify(auth,null,2));
console.log('2FA disabled.');
"
sudo systemctl restart invoicehub
```
Then log in (no TOTP required), and re-enable 2FA from Security settings with a new authenticator.

---

## Cost summary

| Item | Monthly |
|---|---|
| Lightsail instance | ~₹290 |
| Static IP | Free (while attached) |
| Lightsail snapshots | ~₹15 |
| Domain ([accounts.indilok.in](https://accounts.indilok.in)) | already owned |
| HTTPS cert | Free (Let's Encrypt) |
| Google Drive backup | Free (your existing Drive) |
| **Total** | **~₹305/month** |

---

## Need help?

If something goes wrong during setup, capture the output and ask me. Common issues:
- **DNS not propagated** → just wait, re-run install.sh
- **certbot fails** → DNS issue OR port 80 not open in Lightsail firewall
- **Service won't start** → `sudo journalctl -u invoicehub -n 50`
- **`rclone config` confusing** → easier to just SCP the rclone.conf from a laptop where you've configured Drive there
