#!/bin/bash
# ============================================================
#  InvoiceHub restore-from-backup helper
#  Usage:  bash restore.sh <archive.tar.gz>
#          bash restore.sh latest    (downloads newest from Drive)
# ============================================================
set -e

DATA_DIR="/home/ubuntu/invoicehub/data"
RCLONE_REMOTE="gdrive:InvoiceHub-Backups"

if [ $# -lt 1 ]; then
  echo "Usage: $0 <local-archive.tar.gz>  OR  $0 latest"
  echo ""
  echo "Available remote backups:"
  rclone lsf "$RCLONE_REMOTE/" --include "invoicehub_*.tar.gz" | sort -r | head -10
  exit 1
fi

ARCHIVE="$1"
TMP_DIR="/tmp/ihub-restore-$$"
mkdir -p "$TMP_DIR"

if [ "$ARCHIVE" = "latest" ]; then
  LATEST=$(rclone lsf "$RCLONE_REMOTE/" --include "invoicehub_*.tar.gz" | sort -r | head -1)
  if [ -z "$LATEST" ]; then
    echo "ERROR: No backups found on remote."
    exit 1
  fi
  echo ">>> Downloading latest: $LATEST"
  rclone copy "$RCLONE_REMOTE/$LATEST" "$TMP_DIR/"
  ARCHIVE="$TMP_DIR/$LATEST"
fi

if [ ! -f "$ARCHIVE" ]; then
  echo "ERROR: archive not found: $ARCHIVE"
  exit 1
fi

echo ""
echo "!!! WARNING !!!"
echo "This will REPLACE all current data in $DATA_DIR with contents of:"
echo "  $ARCHIVE"
echo ""
read -p "Type YES to proceed: " CONFIRM
if [ "$CONFIRM" != "YES" ]; then
  echo "Aborted."
  exit 0
fi

# Stop service before restoring
sudo systemctl stop invoicehub

# Backup current state aside (just in case)
SAFETY_DIR="$DATA_DIR.before-restore.$(date +%Y%m%d_%H%M%S)"
cp -r "$DATA_DIR" "$SAFETY_DIR"
echo ">>> Current data saved to: $SAFETY_DIR"

# Wipe and extract
rm -rf "$DATA_DIR"/{state.json,auth.json,uploads,uploads-meta.json}
tar -xzf "$ARCHIVE" -C "$DATA_DIR"

# Restart
sudo systemctl start invoicehub
echo ""
echo "✓ Restored from $ARCHIVE"
echo "  Safety copy at: $SAFETY_DIR"
rm -rf "$TMP_DIR"
