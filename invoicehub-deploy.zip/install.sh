#!/bin/bash
# ============================================================
#  InvoiceHub one-shot installer for Ubuntu 22.04 (Lightsail)
#  Run as ubuntu user: bash install.sh
# ============================================================
set -e

# ----- Edit these before running -----
DOMAIN="accounts.indilok.in"
LETSENCRYPT_EMAIL="krunal@indilok.in"   # change to your real email
APP_USERNAME="GTAC-KRUNAL"
APP_PASSWORD="GTAC2026"
NODE_PORT=3000
APP_DIR="/home/ubuntu/invoicehub"
DATA_DIR="/home/ubuntu/invoicehub/data"
# --------------------------------------

echo "=========================================="
echo " InvoiceHub Installer"
echo " Domain: $DOMAIN"
echo " App dir: $APP_DIR"
echo "=========================================="

# 1. System packages
echo ">>> [1/8] Updating system + installing packages..."
sudo apt-get update -y
sudo apt-get install -y curl ca-certificates gnupg nginx ufw rclone unzip

# 2. Node.js 20 LTS
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]; then
  echo ">>> [2/8] Installing Node.js 20 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
else
  echo ">>> [2/8] Node $(node -v) already installed."
fi

# 3. App files
echo ">>> [3/8] Setting up app directory..."
mkdir -p "$APP_DIR" "$DATA_DIR"
# Files should already be in $APP_DIR before running this. If not, error.
if [ ! -f "$APP_DIR/server.js" ] || [ ! -f "$APP_DIR/package.json" ] || [ ! -f "$APP_DIR/public/index.html" ]; then
  echo "ERROR: $APP_DIR must already contain server.js, package.json, and public/index.html before running this installer."
  echo "Upload files first via SCP, then re-run this script."
  exit 1
fi

cd "$APP_DIR"
echo ">>> Installing npm dependencies..."
npm install --omit=dev --silent

# 4. Initialize auth (only if not yet initialized)
if [ ! -f "$DATA_DIR/auth.json" ]; then
  echo ">>> [4/8] Bootstrapping auth (one-time)..."
  PORT=$NODE_PORT INITIAL_USERNAME="$APP_USERNAME" INITIAL_PASSWORD="$APP_PASSWORD" \
    timeout 5 node server.js >/dev/null 2>&1 || true
else
  echo ">>> [4/8] Auth already initialized — skipping."
fi

# 5. Systemd service
echo ">>> [5/8] Creating systemd service..."
sudo tee /etc/systemd/system/invoicehub.service >/dev/null <<EOF
[Unit]
Description=InvoiceHub Server
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=PORT=$NODE_PORT
Environment=DATA_DIR=$DATA_DIR
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=5
StandardOutput=append:/var/log/invoicehub.log
StandardError=append:/var/log/invoicehub.log

[Install]
WantedBy=multi-user.target
EOF

sudo touch /var/log/invoicehub.log
sudo chown ubuntu:ubuntu /var/log/invoicehub.log

sudo systemctl daemon-reload
sudo systemctl enable invoicehub
sudo systemctl restart invoicehub
sleep 2

# 6. Nginx (HTTP only initially; certbot will upgrade to HTTPS)
echo ">>> [6/8] Configuring nginx..."
sudo tee /etc/nginx/sites-available/invoicehub >/dev/null <<EOF
server {
    listen 80;
    server_name $DOMAIN;

    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:$NODE_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }
}
EOF
sudo ln -sf /etc/nginx/sites-available/invoicehub /etc/nginx/sites-enabled/invoicehub
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx

# 7. UFW firewall
echo ">>> [7/8] Configuring firewall..."
sudo ufw --force allow OpenSSH
sudo ufw --force allow 'Nginx Full'
sudo ufw --force enable

# 8. HTTPS with Let's Encrypt
echo ">>> [8/8] Setting up HTTPS (Let's Encrypt)..."
sudo apt-get install -y certbot python3-certbot-nginx
echo ""
echo "About to request a Let's Encrypt certificate for $DOMAIN."
echo "Make sure DNS A record $DOMAIN -> this server's IP is set and propagated."
echo ""
read -p "Press ENTER to continue, or Ctrl+C to abort..."

sudo certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$LETSENCRYPT_EMAIL" --redirect

echo ""
echo "=========================================="
echo " ✓ Installation complete!"
echo "=========================================="
echo " Visit: https://$DOMAIN"
echo " Login: $APP_USERNAME / $APP_PASSWORD"
echo ""
echo " Next steps:"
echo " 1. Visit the URL and sign in"
echo " 2. Open Security settings -> Enable 2FA"
echo " 3. Configure Google Drive backup:  rclone config  (see STEP_BY_STEP.md)"
echo "=========================================="
